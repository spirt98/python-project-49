from games.even import game_even


def main():
    game_even()


if __name__ == "__main__":
    main()
