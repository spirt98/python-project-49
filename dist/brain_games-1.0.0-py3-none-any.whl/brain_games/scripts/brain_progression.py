from games.progression import game_progression


def main():
    game_progression()


if __name__ == "__main__":
    main()
