# Brain games

The project consists of 2 exciting intellectual games.(even,calc,gcd, progression)

## Installation

1. Clone the repository:
    ```sh
    git clone git clone git@github.com:spirt98/python-project-49.git
    cd python-project-49
    ```
2. Install the application
    ```sh
    make install
    ```
3. Run application
    ```sh
    <!-- run the even -->
    brain-even
    <!-- run the calc -->
    brain-calc
    <!-- run the gcd -->
    brain-gcd
    <!-- run the progression -->
    brain-progression
    ```
