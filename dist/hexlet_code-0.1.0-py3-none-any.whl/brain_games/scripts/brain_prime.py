from games.prime import game_prime


def main():
    game_prime()


if __name__ == "__main__":
    main()
