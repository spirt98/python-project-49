from games.calc import game_calc


def main():
    game_calc()


if __name__ == "__main__":
    main()
